<?php
declare(strict_types=1);

/**
 * api/guild_settings.php
 *
 * GET  ?guild_id=xxx          → サーバー設定を取得
 * POST { guild_id, ...fields } → サーバー設定を upsert
 *
 * テーブル: guild_settings
 *   guild_id              VARCHAR(32) PRIMARY KEY
 *   verify_role_id        VARCHAR(32)
 *   log_channel_id        VARCHAR(32)
 *   admin_role_id         VARCHAR(32)  (空文字 = 管理者権限のみ)
 *   gaikou_category_id    VARCHAR(32)  (空文字 = 無効)
 *   gaikou_mention_role_id VARCHAR(32)
 *   kokumin_category_id   VARCHAR(32)  (空文字 = 無効)
 *   support_category_id   VARCHAR(32)  (空文字 = 無効)
 *   honeypot_channel_id   VARCHAR(32)  (空文字 = 無効)
 *   updated_at            DATETIME
 */

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    // ---- テーブルが無ければ自動作成 ----
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id               VARCHAR(32)  NOT NULL PRIMARY KEY,
            guild_name             VARCHAR(100) NOT NULL DEFAULT "",
            verify_role_id         VARCHAR(32)  NOT NULL DEFAULT "",
            log_channel_id         VARCHAR(32)  NOT NULL DEFAULT "",
            admin_role_id          VARCHAR(32)  NOT NULL DEFAULT "",
            gaikou_category_id     VARCHAR(32)  NOT NULL DEFAULT "",
            gaikou_mention_role_id VARCHAR(32)  NOT NULL DEFAULT "",
            kokumin_category_id    VARCHAR(32)  NOT NULL DEFAULT "",
            support_category_id    VARCHAR(32)  NOT NULL DEFAULT "",
            honeypot_channel_id    VARCHAR(32)  NOT NULL DEFAULT "",
            updated_at             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                                ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );

    // ---- 既存テーブルにカラムが無い場合は追加 (旧バージョンからの移行対応) ----
    $columnsStmt = $pdo->query("SHOW COLUMNS FROM guild_settings LIKE 'honeypot_channel_id'");
    if ($columnsStmt->rowCount() === 0) {
        $pdo->exec(
            "ALTER TABLE guild_settings ADD COLUMN honeypot_channel_id VARCHAR(32) NOT NULL DEFAULT '' AFTER support_category_id"
        );
    }

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    // ---- GET: 設定取得 ----
    if ($method === 'GET') {
        $guildId = isset($_GET['guild_id']) ? trim((string)$_GET['guild_id']) : '';

        if ($guildId === '') {
            discord_verify_json_response(['ok' => false, 'error' => 'guild_id required'], 400);
        }

        $stmt = $pdo->prepare(
            'SELECT * FROM guild_settings WHERE guild_id = ? LIMIT 1'
        );
        $stmt->execute([$guildId]);
        $row = $stmt->fetch();

        discord_verify_json_response([
            'ok'     => true,
            'config' => $row ?: null
        ]);
    }

    // ---- POST: 設定保存 (upsert) ----
    if ($method === 'POST') {
        $raw  = file_get_contents('php://input');
        $body = json_decode($raw ?: '', true);

        if (!is_array($body)) {
            $body = $_POST;
        }

        $guildId = isset($body['guild_id']) ? trim((string)$body['guild_id']) : '';

        if ($guildId === '') {
            discord_verify_json_response(['ok' => false, 'error' => 'guild_id required'], 400);
        }

        $fields = [
            'guild_name',
            'verify_role_id',
            'log_channel_id',
            'admin_role_id',
            'gaikou_category_id',
            'gaikou_mention_role_id',
            'kokumin_category_id',
            'support_category_id',
            'honeypot_channel_id'
        ];

        // 既存行を取得してデフォルト値にする
        $existStmt = $pdo->prepare('SELECT * FROM guild_settings WHERE guild_id = ? LIMIT 1');
        $existStmt->execute([$guildId]);
        $existing = $existStmt->fetch() ?: [];

        $values = ['guild_id' => $guildId];

        foreach ($fields as $field) {
            if (isset($body[$field])) {
                $values[$field] = trim((string)$body[$field]);
            } else {
                $values[$field] = (string)($existing[$field] ?? '');
            }
        }

        $pdo->prepare(
            'INSERT INTO guild_settings
                (guild_id, guild_name, verify_role_id, log_channel_id, admin_role_id,
                 gaikou_category_id, gaikou_mention_role_id, kokumin_category_id,
                 support_category_id, honeypot_channel_id)
             VALUES
                (:guild_id, :guild_name, :verify_role_id, :log_channel_id, :admin_role_id,
                 :gaikou_category_id, :gaikou_mention_role_id, :kokumin_category_id,
                 :support_category_id, :honeypot_channel_id)
             ON DUPLICATE KEY UPDATE
                guild_name             = VALUES(guild_name),
                verify_role_id         = VALUES(verify_role_id),
                log_channel_id         = VALUES(log_channel_id),
                admin_role_id          = VALUES(admin_role_id),
                gaikou_category_id     = VALUES(gaikou_category_id),
                gaikou_mention_role_id = VALUES(gaikou_mention_role_id),
                kokumin_category_id    = VALUES(kokumin_category_id),
                support_category_id    = VALUES(support_category_id),
                honeypot_channel_id    = VALUES(honeypot_channel_id),
                updated_at             = NOW()'
        )->execute([
            ':guild_id'               => $values['guild_id'],
            ':guild_name'             => $values['guild_name'],
            ':verify_role_id'         => $values['verify_role_id'],
            ':log_channel_id'         => $values['log_channel_id'],
            ':admin_role_id'          => $values['admin_role_id'],
            ':gaikou_category_id'     => $values['gaikou_category_id'],
            ':gaikou_mention_role_id' => $values['gaikou_mention_role_id'],
            ':kokumin_category_id'    => $values['kokumin_category_id'],
            ':support_category_id'    => $values['support_category_id'],
            ':honeypot_channel_id'    => $values['honeypot_channel_id']
        ]);

        discord_verify_json_response(['ok' => true]);
    }

    discord_verify_json_response(['ok' => false, 'error' => 'method not allowed'], 405);

} catch (Throwable $e) {
    discord_verify_json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}