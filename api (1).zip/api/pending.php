<?php
declare(strict_types=1);

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    $stmt = $pdo->query(
        'SELECT
            id,
            guild_id,
            user_id,
            ip_country,
            is_allowed_country,
            is_duplicate_ip,
            status,
            created_at,
            risk_isp,
            risk_organization,
            risk_asn,
            risk_score,
            risk_flags
         FROM verifications
         WHERE processed = 0
         ORDER BY id ASC
         LIMIT 20'
    );

    $items = $stmt->fetchAll();

    discord_verify_json_response([
        'ok' => true,
        'items' => $items
    ]);
} catch (Throwable $e) {
    discord_verify_json_response([
        'ok' => false,
        'error' => $e->getMessage()
    ], 500);
}