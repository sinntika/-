<?php
declare(strict_types=1);

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    $rawBody = file_get_contents('php://input');
    $jsonBody = json_decode($rawBody ?: '', true);

    if (!is_array($jsonBody)) {
        $jsonBody = $_POST;
    }

    $id = isset($jsonBody['id']) ? (int)$jsonBody['id'] : 0;

    if ($id <= 0) {
        discord_verify_json_response([
            'ok' => false,
            'error' => 'invalid id'
        ], 400);
    }

    $stmt = $pdo->prepare(
        'UPDATE verifications
         SET processed = 1,
             processed_at = NOW()
         WHERE id = ?'
    );

    $stmt->execute([$id]);

    discord_verify_json_response([
        'ok' => true,
        'updated' => $stmt->rowCount()
    ]);
} catch (Throwable $e) {
    discord_verify_json_response([
        'ok' => false,
        'error' => $e->getMessage()
    ], 500);
}