<?php
declare(strict_types=1);

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    $rawBody = file_get_contents('php://input');
    $jsonBody = json_decode($rawBody ?: '', true);

    if (!is_array($jsonBody)) {
        $jsonBody = $_POST;
    }

    $guildId = isset($jsonBody['guild_id']) ? trim((string)$jsonBody['guild_id']) : '';
    $userId = isset($jsonBody['user_id']) ? trim((string)$jsonBody['user_id']) : '';

    if ($guildId === '' || $userId === '') {
        discord_verify_json_response([
            'ok' => false,
            'error' => 'invalid params'
        ], 400);
    }

    $stmt = $pdo->prepare(
        'DELETE FROM verifications
         WHERE guild_id = ?
           AND user_id = ?'
    );

    $stmt->execute([$guildId, $userId]);

    discord_verify_json_response([
        'ok' => true,
        'deleted' => $stmt->rowCount()
    ]);
} catch (Throwable $e) {
    discord_verify_json_response([
        'ok' => false,
        'error' => $e->getMessage()
    ], 500);
}