<?php
declare(strict_types=1);

/**
 * api/check_verified.php
 *
 * GET ?user_id=xxx
 *
 * 指定したDiscordユーザーが、いずれかのサーバーで
 * 1回以上 status='approved' になっているかを返す。
 * (mcid登録コマンドのゲート判定用。guild_idは問わない)
 */

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    $userId = isset($_GET['user_id']) ? trim((string)$_GET['user_id']) : '';

    if ($userId === '') {
        discord_verify_json_response(['ok' => false, 'error' => 'user_id required'], 400);
    }

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) AS cnt
         FROM verifications
         WHERE user_id = ?
           AND status = 'approved'"
    );
    $stmt->execute([$userId]);
    $row = $stmt->fetch();

    $isVerified = (int)($row['cnt'] ?? 0) > 0;

    discord_verify_json_response([
        'ok'          => true,
        'is_verified' => $isVerified
    ]);

} catch (Throwable $e) {
    discord_verify_json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}
