<?php
declare(strict_types=1);

/**
 * api/mcid_register.php
 *
 * POST { discord_id, platform: "java"|"bedrock", mcid: "..." }
 *
 * platform=java の場合:
 *   Mojang API (api.mojang.com) でユーザー名の実在確認 → UUIDを取得
 *
 * platform=bedrock の場合:
 *   GeyserMC公式API (api.geysermc.org) でゲーマータグの実在確認 → XUIDを取得
 *   XUIDからFloodgate形式のUUID (00000000-0000-0000-0009-XXXXXXXXXXXX) を生成
 *
 * 1 discord_id につき 1レコードのみ (上書き可)。
 */

function mcid_http_get_json(string $url, int $timeoutSec = 8): array
{
    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeoutSec,
        CURLOPT_CONNECTTIMEOUT => $timeoutSec,
        CURLOPT_USERAGENT      => 'rarala.net-mcid-register/1.0',
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $body = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($body === false) {
        return ['ok' => false, 'http_code' => 0, 'error' => $error, 'data' => null];
    }

    $data = json_decode((string)$body, true);

    return [
        'ok'        => $httpCode >= 200 && $httpCode < 300,
        'http_code' => $httpCode,
        'error'     => null,
        'data'      => $data
    ];
}

/**
 * Java版ユーザー名をMojang APIで実在確認する。
 * 戻り値: ['found' => bool, 'username' => string, 'uuid' => string(36, hyphenated)]
 */
function mcid_lookup_java(string $username): array
{
    $encoded = rawurlencode($username);
    $result  = mcid_http_get_json("https://api.mojang.com/users/profiles/minecraft/{$encoded}");

    if (!$result['ok'] || !is_array($result['data']) || empty($result['data']['id'])) {
        return ['found' => false, 'username' => '', 'uuid' => ''];
    }

    $rawId = (string)$result['data']['id']; // ハイフン無し32文字
    $name  = (string)($result['data']['name'] ?? $username);

    $uuid = mcid_format_uuid_with_hyphens($rawId);

    return ['found' => true, 'username' => $name, 'uuid' => $uuid];
}

/**
 * Bedrock版ゲーマータグをGeyserMC公式APIで実在確認する。
 * 戻り値: ['found' => bool, 'xuid' => string, 'uuid' => string(Floodgate形式)]
 */
function mcid_lookup_bedrock(string $gamertag): array
{
    $encoded = rawurlencode($gamertag);
    $result  = mcid_http_get_json("https://api.geysermc.org/v2/xbox/xuid/{$encoded}");

    if (!$result['ok'] || !is_array($result['data']) || empty($result['data']['xuid'])) {
        return ['found' => false, 'xuid' => '', 'uuid' => ''];
    }

    $xuid = (string)$result['data']['xuid'];
    $uuid = mcid_xuid_to_floodgate_uuid($xuid);

    return ['found' => true, 'xuid' => $xuid, 'uuid' => $uuid];
}

/**
 * ハイフン無し32文字のUUIDを標準的なハイフン付き36文字形式に変換する。
 */
function mcid_format_uuid_with_hyphens(string $raw): string
{
    $raw = strtolower(preg_replace('/[^a-f0-9]/i', '', $raw) ?? '');

    if (strlen($raw) !== 32) {
        return $raw;
    }

    return sprintf(
        '%s-%s-%s-%s-%s',
        substr($raw, 0, 8),
        substr($raw, 8, 4),
        substr($raw, 12, 4),
        substr($raw, 16, 4),
        substr($raw, 20, 12)
    );
}

/**
 * XUID (10進数の文字列) を Floodgate形式のUUID に変換する。
 * Floodgateの標準フォーマット: 00000000-0000-0000-0009-XXXXXXXXXXXX
 * (下12桁は XUID を16進数化し、16桁に0埋めしたもの)
 */
function mcid_xuid_to_floodgate_uuid(string $xuid): string
{
    // XUIDは64bit符号無し整数として扱う (PHPのintは64bit環境前提)
    $xuidInt = (string)$xuid;

    // bcmath が使えれば正確に変換、無ければgmpにフォールバック
    if (function_exists('bcmod') && function_exists('bcdiv')) {
        $hex = mcid_dec_to_hex_bc($xuidInt);
    } elseif (function_exists('gmp_init')) {
        $hex = gmp_strval(gmp_init($xuidInt, 10), 16);
    } else {
        // 最終手段: 通常のint変換 (PHPが64bit環境であることが前提)
        $hex = dechex((int)$xuidInt);
    }

    $hex = strtolower($hex);
    $hex = str_pad($hex, 16, '0', STR_PAD_LEFT);

    // 16桁を 4-4-4-4 ではなく Floodgateの仕様通り12桁部分にそのまま使う
    // 00000000-0000-0000-0009-XXXXXXXXXXXX (Xは12桁)
    $last12 = substr($hex, -12);
    $last12 = str_pad($last12, 12, '0', STR_PAD_LEFT);

    return '00000000-0000-0000-0009-' . $last12;
}

/**
 * bcmathを使った10進数→16進数変換 (大きな数値を正確に扱うため)
 */
function mcid_dec_to_hex_bc(string $dec): string
{
    $hexChars = '0123456789abcdef';
    $hex = '';

    if ($dec === '0') {
        return '0';
    }

    while (bccomp($dec, '0') > 0) {
        $remainder = (int)bcmod($dec, '16');
        $hex = $hexChars[$remainder] . $hex;
        $dec = bcdiv($dec, '16', 0);
    }

    return $hex;
}

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    // ---- テーブルが無ければ自動作成 ----
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS mcid_links (
            discord_id    VARCHAR(32)            NOT NULL PRIMARY KEY,
            platform      ENUM('java','bedrock') NOT NULL,
            mc_username   VARCHAR(32)             NOT NULL,
            mc_uuid       VARCHAR(36)             NOT NULL,
            xuid          VARCHAR(32)             NULL,
            registered_at DATETIME                NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME                NOT NULL DEFAULT CURRENT_TIMESTAMP
                                                   ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_mc_uuid (mc_uuid),
            INDEX idx_platform (platform)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    if ($method !== 'POST') {
        discord_verify_json_response(['ok' => false, 'error' => 'method not allowed'], 405);
    }

    $raw  = file_get_contents('php://input');
    $body = json_decode($raw ?: '', true);

    if (!is_array($body)) {
        $body = $_POST;
    }

    $discordId = isset($body['discord_id']) ? trim((string)$body['discord_id']) : '';
    $platform  = isset($body['platform'])   ? strtolower(trim((string)$body['platform'])) : '';
    $mcid      = isset($body['mcid'])       ? trim((string)$body['mcid']) : '';

    if ($discordId === '' || $mcid === '') {
        discord_verify_json_response(['ok' => false, 'error' => 'discord_id and mcid required'], 400);
    }

    if (!in_array($platform, ['java', 'bedrock'], true)) {
        discord_verify_json_response(['ok' => false, 'error' => 'platform must be "java" or "bedrock"'], 400);
    }

    // ---- 実在確認 ----
    if ($platform === 'java') {
        // Java版ユーザー名のフォーマットチェック (3-16文字、英数字とアンダースコアのみ)
        if (!preg_match('/^[A-Za-z0-9_]{3,16}$/', $mcid)) {
            discord_verify_json_response([
                'ok'    => false,
                'error' => 'invalid_java_username_format'
            ], 400);
        }

        $lookup = mcid_lookup_java($mcid);

        if (!$lookup['found']) {
            discord_verify_json_response([
                'ok'    => false,
                'error' => 'java_username_not_found'
            ], 404);
        }

        $finalUsername = $lookup['username'];
        $finalUuid     = $lookup['uuid'];
        $finalXuid     = null;
    } else {
        // Bedrock版ゲーマータグのフォーマットチェック (1-15文字、Xbox仕様に準拠)
        if (mb_strlen($mcid) < 1 || mb_strlen($mcid) > 15) {
            discord_verify_json_response([
                'ok'    => false,
                'error' => 'invalid_bedrock_gamertag_format'
            ], 400);
        }

        $lookup = mcid_lookup_bedrock($mcid);

        if (!$lookup['found']) {
            discord_verify_json_response([
                'ok'    => false,
                'error' => 'bedrock_gamertag_not_found'
            ], 404);
        }

        $finalUsername = $mcid;
        $finalUuid     = $lookup['uuid'];
        $finalXuid     = $lookup['xuid'];
    }

    // ---- 同じMCIDが既に別のDiscordユーザーに紐付いていないかチェック ----
    $dupStmt = $pdo->prepare(
        'SELECT discord_id FROM mcid_links WHERE mc_uuid = ? AND discord_id != ? LIMIT 1'
    );
    $dupStmt->execute([$finalUuid, $discordId]);
    $dup = $dupStmt->fetch();

    if ($dup) {
        discord_verify_json_response([
            'ok'    => false,
            'error' => 'mcid_already_linked_to_another_discord_user'
        ], 409);
    }

    // ---- upsert ----
    $pdo->prepare(
        'INSERT INTO mcid_links (discord_id, platform, mc_username, mc_uuid, xuid)
         VALUES (:discord_id, :platform, :mc_username, :mc_uuid, :xuid)
         ON DUPLICATE KEY UPDATE
            platform    = VALUES(platform),
            mc_username = VALUES(mc_username),
            mc_uuid     = VALUES(mc_uuid),
            xuid        = VALUES(xuid),
            updated_at  = NOW()'
    )->execute([
        ':discord_id'  => $discordId,
        ':platform'    => $platform,
        ':mc_username' => $finalUsername,
        ':mc_uuid'     => $finalUuid,
        ':xuid'        => $finalXuid
    ]);

    discord_verify_json_response([
        'ok'       => true,
        'platform' => $platform,
        'username' => $finalUsername,
        'uuid'     => $finalUuid
    ]);

} catch (Throwable $e) {
    discord_verify_json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}
