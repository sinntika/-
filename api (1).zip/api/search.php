<?php
declare(strict_types=1);

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    $guildId = isset($_GET['guild_id']) ? trim((string)$_GET['guild_id']) : '';
    $userId = isset($_GET['user_id']) ? trim((string)$_GET['user_id']) : '';

    if ($guildId === '' || $userId === '') {
        discord_verify_json_response([
            'ok' => false,
            'error' => 'invalid params'
        ], 400);
    }

    $countStmt = $pdo->prepare(
        'SELECT COUNT(*) AS total_records
         FROM verifications
         WHERE guild_id = ?
           AND user_id = ?'
    );

    $countStmt->execute([$guildId, $userId]);
    $countRow = $countStmt->fetch();
    $totalRecords = $countRow ? (int)$countRow['total_records'] : 0;

    $stmt = $pdo->prepare(
        'SELECT
            id,
            user_id,
            ip_country,
            is_allowed_country,
            is_duplicate_ip,
            status,
            created_at,
            processed,
            processed_at,
            risk_isp,
            risk_organization,
            risk_asn,
            risk_score,
            risk_flags
         FROM verifications
         WHERE guild_id = ?
           AND user_id = ?
         ORDER BY id DESC
         LIMIT 1'
    );

    $stmt->execute([$guildId, $userId]);
    $row = $stmt->fetch();

    discord_verify_json_response([
        'ok' => true,
        'item' => $row ?: null,
        'total_records' => $totalRecords
    ]);
} catch (Throwable $e) {
    discord_verify_json_response([
        'ok' => false,
        'error' => $e->getMessage()
    ], 500);
}