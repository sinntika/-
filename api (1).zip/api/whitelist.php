<?php
declare(strict_types=1);

/**
 * api/whitelist.php
 *
 * GET → 全登録済みプレイヤーの一覧を返す (Minecraftプラグインがポーリングする用)
 *
 * レスポンス:
 * {
 *   "ok": true,
 *   "players": [
 *     { "discord_id": "...", "platform": "java", "username": "Notch", "uuid": "069a79f4-44e9-4726-a5be-fca90e38aaf5" },
 *     { "discord_id": "...", "platform": "bedrock", "username": "SomeGamertag", "uuid": "00000000-0000-0000-0009-XXXXXXXXXXXX", "xuid": "..." }
 *   ],
 *   "generated_at": "2026-06-23 12:00:00"
 * }
 */

try {
    require_once __DIR__ . '/../lib/db.php';

    discord_verify_require_api_auth($config);

    // mcid_links テーブルが無い場合は空配列を返す (まだ誰も登録していない初期状態)
    $tableExistsStmt = $pdo->query(
        "SELECT COUNT(*) AS cnt FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = 'mcid_links'"
    );
    $tableExists = (int)($tableExistsStmt->fetch()['cnt'] ?? 0) > 0;

    if (!$tableExists) {
        discord_verify_json_response([
            'ok'           => true,
            'players'      => [],
            'generated_at' => date('Y-m-d H:i:s')
        ]);
    }

    $stmt = $pdo->query(
        'SELECT discord_id, platform, mc_username, mc_uuid, xuid
         FROM mcid_links
         ORDER BY registered_at ASC'
    );

    $rows = $stmt->fetchAll();

    $players = array_map(function (array $row): array {
        $entry = [
            'discord_id' => (string)$row['discord_id'],
            'platform'   => (string)$row['platform'],
            'username'   => (string)$row['mc_username'],
            'uuid'       => (string)$row['mc_uuid']
        ];

        if ($row['platform'] === 'bedrock' && !empty($row['xuid'])) {
            $entry['xuid'] = (string)$row['xuid'];
        }

        return $entry;
    }, $rows);

    discord_verify_json_response([
        'ok'           => true,
        'players'      => $players,
        'generated_at' => date('Y-m-d H:i:s')
    ]);

} catch (Throwable $e) {
    discord_verify_json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}
