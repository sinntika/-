<?php
declare(strict_types=1);

if (!function_exists('discord_verify_load_env_file')) {
    function discord_verify_load_env_file(string $path): void
    {
        if (!is_file($path) || !is_readable($path)) {
            return;
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        if ($lines === false) {
            return;
        }

        foreach ($lines as $line) {
            $line = trim($line);

            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $pos = strpos($line, '=');

            if ($pos === false) {
                continue;
            }

            $key = trim(substr($line, 0, $pos));
            $value = trim(substr($line, $pos + 1));

            if ($key === '') {
                continue;
            }

            if (
                (str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                (str_starts_with($value, "'") && str_ends_with($value, "'"))
            ) {
                $value = substr($value, 1, -1);
            }

            if (getenv($key) === false) {
                putenv($key . '=' . $value);
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

if (!function_exists('discord_verify_env')) {
    function discord_verify_env(string $key, ?string $default = null, bool $required = false): string
    {
        $value = getenv($key);

        if ($value === false || trim((string)$value) === '') {
            if ($required) {
                throw new RuntimeException('Missing environment variable: ' . $key);
            }

            return $default ?? '';
        }

        return trim((string)$value);
    }
}

if (!function_exists('discord_verify_api_token_from_request')) {
    function discord_verify_api_token_from_request(): string
    {
        if (!empty($_SERVER['HTTP_X_INTERNAL_TOKEN'])) {
            return trim((string)$_SERVER['HTTP_X_INTERNAL_TOKEN']);
        }

        $authorization = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

        if ($authorization === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $authorization = (string)$_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        }

        if ($authorization === '' && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();

            foreach ($headers as $name => $value) {
                $lowerName = strtolower((string)$name);

                if ($lowerName === 'x-internal-token') {
                    return trim((string)$value);
                }

                if ($lowerName === 'authorization') {
                    $authorization = (string)$value;
                }
            }
        }

        if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $matches)) {
            return trim($matches[1]);
        }

        if (isset($_GET['internal_token'])) {
            return trim((string)$_GET['internal_token']);
        }

        if (isset($_POST['internal_token'])) {
            return trim((string)$_POST['internal_token']);
        }

        return '';
    }
}

if (!function_exists('discord_verify_json_response')) {
    function discord_verify_json_response(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode(
            $data,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        exit;
    }
}

if (!function_exists('discord_verify_require_api_auth')) {
    function discord_verify_require_api_auth(array $config): void
    {
        $givenToken = discord_verify_api_token_from_request();
        $expectedToken = trim((string)$config['internal_api_token']);

        if ($givenToken === '' || $expectedToken === '' || !hash_equals($expectedToken, $givenToken)) {
            discord_verify_json_response(
                [
                    'ok' => false,
                    'error' => 'forbidden'
                ],
                403
            );
        }
    }
}

discord_verify_load_env_file(__DIR__ . '/../../discord_verify.env');
discord_verify_load_env_file(__DIR__ . '/../.env');

return [
    'db_host' => discord_verify_env('DISCORD_VERIFY_DB_HOST', 'localhost', true),
    'db_name' => discord_verify_env('DISCORD_VERIFY_DB_NAME', null, true),
    'db_user' => discord_verify_env('DISCORD_VERIFY_DB_USER', null, true),
    'db_pass' => discord_verify_env('DISCORD_VERIFY_DB_PASS', null, true),

    'verify_token_secret' => discord_verify_env('DISCORD_VERIFY_TOKEN_SECRET', null, true),
    'internal_api_token' => discord_verify_env('DISCORD_INTERNAL_API_TOKEN', null, true),
    'ip_hash_salt' => discord_verify_env('DISCORD_IP_HASH_SALT', null, true),

    'allowed_country' => strtoupper(discord_verify_env('DISCORD_ALLOWED_COUNTRY', 'JP', false)),
    'country_mode' => strtolower(discord_verify_env('DISCORD_COUNTRY_MODE', 'fixed', false)),
    'site_title' => discord_verify_env('DISCORD_VERIFY_SITE_TITLE', '認証BOT', false)
];