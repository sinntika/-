<?php
declare(strict_types=1);

if (!function_exists('discord_verify_valid_ip_or_empty')) {
    function discord_verify_valid_ip_or_empty(string $ip): string
    {
        $ip = trim($ip);

        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }

        return '';
    }
}

if (!function_exists('discord_verify_client_ip')) {
    function discord_verify_client_ip(): string
    {
        $candidateHeaders = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP'
        ];

        foreach ($candidateHeaders as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = discord_verify_valid_ip_or_empty((string)$_SERVER[$header]);

                if ($ip !== '') {
                    return $ip;
                }
            }
        }

        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $parts = explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR']);

            foreach ($parts as $part) {
                $ip = discord_verify_valid_ip_or_empty($part);

                if ($ip !== '') {
                    return $ip;
                }
            }
        }

        return discord_verify_valid_ip_or_empty((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    }
}

if (!function_exists('discord_verify_ip_hash')) {
    function discord_verify_ip_hash(string $ip, string $salt): string
    {
        return hash('sha256', $salt . ':' . $ip);
    }
}

if (!function_exists('discord_verify_user_agent_hash')) {
    function discord_verify_user_agent_hash(string $salt): ?string
    {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if ($ua === '') {
            return null;
        }

        return hash('sha256', $salt . ':ua:' . $ua);
    }
}

if (!function_exists('discord_verify_country_of_ip')) {
    function discord_verify_country_of_ip(string $ip, array $config): string
    {
        $mode = $config['country_mode'] ?? 'fixed';

        if ($mode === 'fixed') {
            return strtoupper($config['allowed_country'] ?? 'JP');
        }

        return 'UNKNOWN';
    }
}