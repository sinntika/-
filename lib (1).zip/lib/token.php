<?php
declare(strict_types=1);

if (!function_exists('discord_verify_base64url_decode')) {
    function discord_verify_base64url_decode(string $data): string|false
    {
        $remainder = strlen($data) % 4;

        if ($remainder > 0) {
            $data .= str_repeat('=', 4 - $remainder);
        }

        return base64_decode(strtr($data, '-_', '+/'), true);
    }
}

if (!function_exists('discord_verify_base64url_encode')) {
    function discord_verify_base64url_encode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}

if (!function_exists('discord_verify_token_payload')) {
    function discord_verify_token_payload(string $token, string $secret): ?array
    {
        $parts = explode('.', $token);

        if (count($parts) !== 2) {
            return null;
        }

        [$body, $signature] = $parts;

        if ($body === '' || $signature === '') {
            return null;
        }

        $expectedSignature = discord_verify_base64url_encode(
            hash_hmac('sha256', $body, $secret, true)
        );

        if (!hash_equals($expectedSignature, $signature)) {
            return null;
        }

        $json = discord_verify_base64url_decode($body);

        if ($json === false) {
            return null;
        }

        $payload = json_decode($json, true);

        if (!is_array($payload)) {
            return null;
        }

        if (
            !isset($payload['guildId']) ||
            !isset($payload['userId']) ||
            !isset($payload['exp'])
        ) {
            return null;
        }

        if (!is_string($payload['guildId']) || !is_string($payload['userId'])) {
            return null;
        }

        if (!is_numeric($payload['exp'])) {
            return null;
        }

        $nowMs = (int)floor(microtime(true) * 1000);

        if ($nowMs > (int)$payload['exp']) {
            return null;
        }

        return [
            'guildId' => $payload['guildId'],
            'userId' => $payload['userId'],
            'exp' => (int)$payload['exp']
        ];
    }
}